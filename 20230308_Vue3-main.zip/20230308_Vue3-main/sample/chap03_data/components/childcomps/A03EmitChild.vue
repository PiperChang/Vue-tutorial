<template>
  <h5>A03 Emits Child Component</h5>  

  <div>
    <button>Num</button>
    <button>Data</button>
  </div>

</template>

<script>
export default {
  data() {
    return {
      num: 10,
      name: 'NolBu',
      arr: [10, 20],
      user: {name: 'HungBu', age: 20}
    }
  },
}
</script>
