<template>
  <h5>A02 Props Child Component</h5>

  <div>
    
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
