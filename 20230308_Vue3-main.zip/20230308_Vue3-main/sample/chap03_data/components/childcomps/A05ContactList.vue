<template>
  <table class="table">
    <thead>
      <tr>
        <th>번호</th><th>이름</th><th>전화번호</th><th>주소</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
