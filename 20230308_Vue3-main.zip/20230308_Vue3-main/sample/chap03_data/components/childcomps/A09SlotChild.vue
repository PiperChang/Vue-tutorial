<template>
  <h5>A09 Slot Child Component</h5>

  <div>
    
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
