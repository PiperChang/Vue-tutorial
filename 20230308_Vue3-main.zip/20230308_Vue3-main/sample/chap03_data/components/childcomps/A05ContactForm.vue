<template>
  <form>
    <div class="input-group">
      <input type="text" class="form-control"/>
      <div class="input-group-append">
        <button type="submit" class="btn btn-primary mr-1">Submit</button>
      </div>
    </div>  
  </form>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
