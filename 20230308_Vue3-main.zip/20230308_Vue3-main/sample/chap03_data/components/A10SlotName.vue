<template>
  <h3>A10 Slot Name</h3>

  <A10SlotNameChild>
    
  </A10SlotNameChild>
</template>

<script>
import A10SlotNameChild from './childcomps/A10SlotNameChild.vue'

export default {
  components: { A10SlotNameChild },
  data() {
    return {
      
    }
  }
}
</script>
