<template>
  <h3>A01 Component</h3>
  
  
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
