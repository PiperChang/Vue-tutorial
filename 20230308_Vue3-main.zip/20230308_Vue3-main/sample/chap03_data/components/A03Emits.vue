<template>
  <h3>A03 Emits</h3>  

  <div>
    Counter: <br>
    <br>
    Object: <br>
  </div>

  <hr>

  <A03EmitChild></A03EmitChild>
</template>

<script>
import A03EmitChild from './childcomps/A03EmitChild.vue';
export default {
  components: { A03EmitChild },
  data() {
    return {
      
    }
  },
  methods: {
    
  }
}
</script>
