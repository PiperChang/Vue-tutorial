<template>
  <h3>A05 Suspense - Vue3</h3>

</template>

<script>
export default {
  components: {},
  
}
</script>

<style scoped>
  .dialog { position: fixed; top: 50px; left: 30%; width: 600px; height: 200px; z-index: 99999; border: 1px solid gray; background-color: white; padding: 10px; }
</style>
