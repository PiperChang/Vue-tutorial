<template>
  <h3>잠시 후 다시 방문해 주세요..</h3>
</template>