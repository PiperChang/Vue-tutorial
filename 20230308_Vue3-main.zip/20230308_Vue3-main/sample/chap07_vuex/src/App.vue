<template>
  <div class="card-body">
    <h1>Chap07 Vuex TodoList</h1>

    
  </div>
</template>

<script>
// npm i vuex

export default {
  components: {  },
}
</script>

<style scoped>

</style>
