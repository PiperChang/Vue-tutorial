<template>
  <div>
    <h3>Counter</h3>

    <div>
      Num: <br>
      <button>+</button>
      <button>-</button>
    </div>
</div>
</template>

<script>
export default {
  
}
</script>