<template>
  <div>
    <table class="table">
      <thead>
        <tr>
            <th style="{width:'10%'}">ID</th>
            <th>Todo</th>
            <th style="{width:'10%'}">Complete</th>
            <th style="{width:'10%'}">Delete</th>
        </tr>
      </thead>
      <tbody>
        
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  
}
</script>

<style scoped>

</style>
