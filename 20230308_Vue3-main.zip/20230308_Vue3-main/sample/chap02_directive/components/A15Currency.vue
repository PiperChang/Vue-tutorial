<template>
  <h3>A15 Currency</h3>

  Qty: <input type="text" class="form-control">
  Cost: <input type="text" class="form-control">
  Country: 
    <select class="form-control">
      <option></option>     
    </select>
  <br>
  <div>Total: </div>
  <div>Total: <span></span></div>  
</template>

<script>
export default {
  
}
</script>
