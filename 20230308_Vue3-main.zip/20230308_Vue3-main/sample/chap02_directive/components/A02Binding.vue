<template>
  <h3>A02 Binding</h3>
  바인딩 식 내부에서는 식만 사용 가능<br>
  <br>

  <div>
    <h5>1. 일반적 바인딩</h5>
    일반적인 단방향 바인딩: <br>
    함수의 리턴값: <br>
    함수의 리턴값: <br>
    배열: <br>
    객체: <br>
  </div>
  <br>

  <div>
    <h5>2. 바인딩 연산</h5>
    일반적 연산: <br>
    속성 참조: <br>
    속성 참조 연산: <br>
    비교 연산: <br>
    비교 연산: <br>
    삼항 연산: <br>
  </div>
  <br>

  <div>
    <h5>3. 바인딩 관련 지시자</h5>
    v-text: <span></span><br>
    v-html: <span></span><br>
    v-once: <span></span><br>
    v-pre: <span></span><br>
    <br>
    <button>Change</button>
    <button>Change</button>
    <br>
  </div>

  <div>
    Data에 존재하지 않는 변수: 
    Data에 존재하지 않는 객체: 
  </div>
</template>

<script>
export default {
  
}
</script>
